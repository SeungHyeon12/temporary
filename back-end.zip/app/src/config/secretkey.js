module.exports = {
    secretKey : 'YoUrSeCrEtKeY', // secret key
    option : {
        algorithm : "HS256", // 옵션 
        expiresIn : "30m",  
        issuer : "djb" 
    }
}